classdef BLS_device < handle

    %======================================================================
    %BLS_DEVICE 
    %
    %PURPOSE: Implements communication with the Mightex BLS LED controller unit.
    %Note that this object's function requires software tools from
    %Mightex's BLS Driver SDK, which must be obtained directly from
    %Mightex. 
    %
    %NOTE: This code requires acess to the SDK for control of the Mightex
    %BLS unit. The version we use in this package is MightexBLSrelease_V1.7_20190218
    %This can be obtained by contacting Mightex. 
    %
    %CLASS METHODS: 
    %
    %BLS_device(): constructor method for BLS device class. The Mightex 
    %SDK files must be on the search path already. 
    %
    %delete(obj): destructor method for device class. 
    %
    %setCurrent(obj,chanNo,A): Change intensity of LED controlled by channel
    %chanNo. 
    %
    %enableChannel(obj,chanNo): Turn ON LED controlled by channel chanNo 
    %
    %disableChannel(obj,chanNo): Turn OFF LED controlled by channel chanNo.
    %
    %======================================================================
    
    properties
        nDevices
        devHandle
        channels
        nChannels
    end
    
    methods
        function obj = BLS_device() %constructor method. Takes string argument that specifies the path to the BLS I/O SDK.
                  
            
            if libisloaded('Mightex_BLSDriver_SDK') %Check if the SDK library is already loaded for the BLS I/O device. If not, load in the library
                display('BLS SDK library is already loaded...');
            else            
                %This should already be on the sesarch path. 
                loadlibrary('Mightex_BLSDriver_SDK.dll','Mightex_BLSDriver_SDK_v3.h'); 

                %NOTE: If this throws an error, remove all 'externC'
                %references from the file header.
                %this was recommended by Mightext to avoid MATLAB compiler errors.
            end
            
            if ~libisloaded('Mightex_BLSDriver_SDK')
                display('error loading BLS Driver Library');
                
            else %if we successfully imported the library, open the device.
                obj.nDevices = calllib('Mightex_BLSDriver_SDK','MTUSB_BLSDriverInitDevices');
                obj.devHandle = calllib('Mightex_BLSDriver_SDK','MTUSB_BLSDriverOpenDevice',obj.nDevices-1);
                obj.nChannels = calllib('Mightex_BLSDriver_SDK','MTUSB_BLSDriverGetChannels',obj.devHandle);
                
                if(obj.devHandle == -1)
                    display('Error opening Mightex BLS I/O Device');
                else
                    display('Mightex BLS I/O Device opened successfully');
                    
                    %Initialize Channel information
                    for i=1:obj.nChannels
                        
                        initChan(i).Name = ['Channel ',num2str(i)];
                        initChan(i).maxCurrent = 1000;
                        initChan(i).setCurrent = 0; %initialize the set current to 0
                        initChan(i).mode = 0; %initialize the mode of the channel to 'DISABLE' to start
                        
                    end
                    
                    obj.channels = initChan; %this is set using a set method defined below
                    
                end
            end
        end
        
        function delete(obj) %destructor method; incorporates the closeout function of the SDK
            flag = calllib('Mightex_BLSDriver_SDK','MTUSB_BLSDriverCloseDevice',obj.devHandle); %make sure we delte the object gracefully.
            if(flag ~= -1)
                display('BLS device successfully closed');
            else
                display('Error closing BLS device');
            end
        end
        
        function obj = setCurrent(obj,chanNo,A) 
            
            %Method changes the set current of channel chanNo to a value of A.
            %NOTE: uses 0.1% units => A = 1000 corresponds to 100% LED
            %power.

            %NOTE: The LED controlled by channel chanNo depends on how your
            %setup is wired; check to see which LED is physically connected
            %to channel ChanNo on the BLS I/O box. 

            if(A <= obj.channels(chanNo).maxCurrent)
                flag = calllib('Mightex_BLSDriver_SDK','MTUSB_BLSDriverSetNormalCurrent',obj.devHandle,chanNo,A);
                
                if(flag == -1)
                    display('Invalid BLS device or channel handle');
                elseif(flag ==1)
                    display('Error while invoking API during BLS channel current change');
                else %If everything looks ok, update the status of the BLS object to reflect the current setting. 
                    display('Current changed');
                    newChans = obj.channels;
                    newChans(chanNo).setCurrent = A;
                    obj.channels = newChans; %see syntax of the set method below.
                    disp(A); 
                end
                
            else
                display('BLS channel ',num2str(chanNo),' requested current is out of bounds');
            end
        end
        
        function obj = enableChannel(obj,chanNo) 
            
            %Method turns ON the LED controlled by channel chanNo. 
            %This is achieved by setting the chanNo mode to '1'
            %through the Mightex SDK library. 
            
            flag = calllib('Mightex_BLSDriver_SDK','MTUSB_BLSDriverSetMode',obj.devHandle,chanNo,1);
            
            if(flag == -1)
                display('Invalid BLS device or channel handle');
            elseif(flag ==1)
                display('Error while invoking API during BLS channel current change');
            else %update the state of the BLS object if everything went correctly. 
                display("LED enabled");
                obj.channels(chanNo).mode = 1;
            end
        end
        
        function obj = disableChannel(obj,chanNo) 
            
            %This method turns OFF the LED controlled by channel chanNo on the BLS 
            %I/O box. 

            %%This is achieved by setting the chanNo mode to '0'
            %through the Mightex SDK library.
            
            flag = calllib('Mightex_BLSDriver_SDK','MTUSB_BLSDriverSetMode',obj.devHandle,chanNo,0);
            
            if(flag == -1)
                display('Invalid BLS device or channel handle');
            elseif(flag ==1)
                display('Error while invoking API during BLS channel current change');
            else
                obj.channels(chanNo).mode = 0;
            end
        end
        
    end
end

