function liveViewScale(obj,event,himage)

%Preview window function that performs automatic live image scaling. 

% Display image data.
minDat = getappdata(himage,'MinVal'); 
maxDat = getappdata(himage,'MaxVal'); 
autoScale = getappdata(himage,'Autoscale'); 

switch autoScale.Value
    case 'Off' %scale according to the specified pixel bounds 
        himage.CData = (event.Data - minDat.Value)*(255/(maxDat.Value - minDat.Value)); 
    case 'On' 
        himage.CData = event.Data*(255/max(event.Data(:))); %apply a max/min scaling
end

