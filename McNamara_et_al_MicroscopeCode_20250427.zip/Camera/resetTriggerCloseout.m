function resetTriggerCloseout(src,event,camObj)

%==========================================================================
%FUNCTION RESETTRIGGERCLOSEOUT(SRC,EVENT,CAMOBJ)
%
%PURPOSE:To reset the trigger mode of camObj (a camera object) to
%'external' upon closing of a live window. 
%
%INPUTS: Src and Event are automatically passed by MATLAB. CAMOBJ is a
%camera object passed automatically. 
%
%OUTPUTS: None. 
%==========================================================================

%close the figure out. 
delete(gcf); 

%reset the trigger mode of the camera. 
camObj.vidSrc.TriggerSource = 'external';

