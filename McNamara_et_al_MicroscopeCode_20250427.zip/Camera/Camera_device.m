classdef Camera_device < handle

    %======================================================================
    %CAMERA_DEVICE
    %
    %PURPOSE: Creates an object to facilitate control of a Hamamatsu Orca
    %Fusion Gen III sCMOS camera. 
    %
    %NOTE: Requires download of Hamamatsu Fusion adapter for MATLAB,
    %available here: https://dcam-api.com/hamamatsu-software/
    %
    %CLASS METHODS: 
    %
    %Camera_device(varargin): Constructor method. Varargin is a string
    %specifying the camera acquisition mode. For our manuscript, the
    %initialization mode was 'external'. This allows the camera to be
    %triggered by voltage pulses from an arduino controller. 
    %
    %delete(obj) %destructor method; clean up the video object
    %when finished. 
    %
    %[frame metaData] = grabFrame(obj,tExp,varargin). Snap an image with
    %exposure time tExp. 
    %
    %frame = grabFluor(obj,tExp,chan,BLS,varargin). Snap a fluorescence
    %image. Implements frame grabbing, but with automated control of LED
    %illumination for fluorescence imaging. Note that method takes a BLS
    %object as an argument => BLS must be pre-loaded to call this method. 
    %
    %obj = setROI(obj,xOffSet,yOffSet,width,height): Used to set acquisitio
    %to only a sub-region of the camera chip. UL corner (xOffset,yOffSet),
    %with dimensions width x height. Units in camera pixels. 
    %
    %obj = resetROI(obj): Used to reset the ROI to full-frame acquisition. 
    %
    %obj = setDMDBoundary(obj,fullFrameIm,setFlag: Used to define a
    %sub-region of the camera ROI that corresponds only to the region that
    %can be illuminated by the DMD 
    %
    %obj = importCalibration(obj,calStruct): Camera calibration data (i.e.
    %data required to set the DMD boundary) can be exported to .mat file by
    %the GUI. This function imports that data and adds it to the camera
    %object. 
    %
    %obj = liveScale(obj,tExp): Initiates a live window with exposures of
    %tExp seconds duration. The view automatically max/min scales the
    %display of each frame. 
    %

    %NOTE: For our manuscript, we triggered camera exposures using a
    %voltage pulse from a Teensy LC Arduino controller with  default baud
    %set to 9600. The arduino was connected to the camera via the coaxial
    %external trigger port. On our PC, the arduino automatically connected
    %to COM4; this may have to be altered for your application. 
    %
    %The reason we use Arduino/external triggering was related to reducing
    %latency associated with initiating an exposure. We found that using
    %software triggering through MATLAB created long (>1 s) delays.
    %Performance was much improved with the Arduino, which we believe
    %justified the extra trouble. To use this triggering mode, the variable
    %argument of the constructor should be 'External' when initializing. 
    %
    %
    %NOTE: Useful resource for understanding and troubleshooting the code below: 
    % https://www.mathworks.com/help/imaq/acquiring-image-data.html
    %======================================================================
    
    properties
        adapter %information on the software adapter that connects MATLAB to the camera
        adapterInfo %metadata for the Hamamatsu hardware adpater
        vid %the high-level MATLAB video object
        vidSrc %the hardware-level video object. Used for changing hardware settings
        fullFrameIm %an image with all DMD pixels = 1 to calibrate the camera ROI.
        arduino %the arduino controller for triggered exposures.
        DMDROI %Object describing the size and position of the DMD's footprint in the camera frame 
 
    end
    
    methods
        function obj = Camera_device(varargin) %constructor method. Takes string arguments for options. 
            obj.adapter = 'hamamatsu';
            obj.adapterInfo = imaqhwinfo(obj.adapter); %log the information for the hardware adapter
            
            if(isempty(varargin))
                obj.vid = videoinput(obj.adapter,obj.adapterInfo.DeviceInfo.DeviceID,...
                    'MONO16_2304x2304_SlowMode'); % start it off in 16-bit full-frame mode by default.
            else %can specify the video format through the optional argument. These are all  properties of the Hamamatsu camera, 
                %You can learn more about the technical details of each in
                %the Hamamatsu documentation. 
                
                switch varargin{1}
                    case 'Slow'
                        obj.vid = videoinput(obj.adapter,obj.adapterInfo.DeviceInfo.DeviceID,...
                            'MONO16_2304x2304_SlowMode');
                    case 'Fast'
                        obj.vid = videoinput(obj.adapter,obj.adapterInfo.DeviceInfo.DeviceID,...
                            'MONO16_2304x2304_FastMode');
                    case 'Faster'
                        obj.vid = videoinput(obj.adapter,obj.adapterInfo.DeviceInfo.DeviceID,...
                            'MONO16_2304x2304_FasterMode');
                    case {'external','External'} %initialize to slow mode, but with external triggering.
                        obj.vid = videoinput(obj.adapter,obj.adapterInfo.DeviceInfo.DeviceID,...
                            'MONO16_2304x2304_SlowMode');
                        obj.vidSrc = 'external'; 
                end
                
            end
            
            %Configure the camera triggering properties.

            obj.vidSrc = getselectedsource(obj.vid);
            triggerconfig(obj.vid,'Manual'); %We'll default to a manual trigger type.
            
            if(isempty(varargin)) %if not specified, we're doing software triggers
                obj.vid.FramesPerTrigger = 1; %default to one frame per trigger issued.
                display([obj.adapterInfo.AdaptorName,' camera object created.']);

            elseif(strcmp(varargin{1},'external') || strcmp(varargin{1},'External')) %For situations where we trigger the camera via a voltage pulse from an Arduino. 
                
                obj.vid.FramesPerTrigger = 1;
                obj.vidSrc.TriggerSource = 'external';
                obj.vidSrc.TriggerGlobalExposure = 'globalreset';
                
                obj.vidSrc.TriggerPolarity = 'positive';
                obj.vid.TriggerRepeat = Inf; %allows us to trigger multiple times once camera is started.
                
                %This settings is for when we're using the Arduino, so
                %initialize the device:
                
                obj.arduino = serialport('COM4',9600); %9600 Arduno is a Teensy LC; default baud is 9600.
                configureTerminator(obj.arduino,"CR"); %not sure if this is required; set the terminator to a carriage return.
                
            else %Catch all for unrecognized modes; default to sotware triggering 
                
                obj.vid.FramesPerTrigger = 1; %default to one frame per trigger issued.
                display([obj.adapterInfo.AdaptorName,' camera object created.']);
                
            end
            
            %Initialize to empty; method is provided below to fill this in.
            obj.fullFrameIm = [];
            obj.DMDROI = [];
       
        end
        
        function delete(obj) %destructor method; clean up the video object
            
            delete(obj.vid); %make sure to clear out the video object first.
            display([obj.adapterInfo.AdaptorName,' camera object unloaded.']);
            
        end
        
        function [frame metaData] = grabFrame(obj,tExp,varargin)
            %Implements simple image acquisition. Takes a single shot with exposure time
            %specified in seconds (tExp). Optional argument is a file path for
            %saving. Note that this is going to be quite slow (~2 sec/image
            %irrespective of exposure time) due to software triggering.
            %
            %Note: triggering is done via software here. Arduino triggering
            %can be used in the next method (grabFluor). 
            
            %Outputs: frame, the captured image. metaData: metadata from
            %the camera. 
            
            if(tExp ~= obj.vidSrc.ExposureTime) %only update the exposure time setting on the hardware if we need to.
                obj.vidSrc.ExposureTime = tExp;
            end
            
            if(tExp >= 0.001)
                [frame metaData] = getsnapshot(obj.vid);
                if(~isempty(varargin))
                    imwrite(frame,varargin{1});
                end
            else
                display('Invalid camera exposure time requested');
            end
        end
        
        function frame = grabFluor(obj,tExp,chan,BLS,varargin)
     
            %More complex version of the grabFrame method that
            %incorporates (1) LED control, (2) camera triggering via the
            %arduino controller and (3) image writing.
            
            %Note: tExp is in SECONDS
            %chan is a string specifying the wavelength of the LED (see
            %switch statement below for options) 

            %varargin: if specified, a path for file writing.
            
            %First, check to see if we have to change the camera's exposure
            %setting.
            
            if(abs(tExp - obj.vidSrc.ExposureTime) > 0.001) %only update the exposure time setting if we need to.
                obj.vidSrc.ExposureTime = tExp;
            end
            
            if(isrunning(obj.vid))
                
                trigger(obj.vid); %Put the camera into acquisition mode. 
                
                switch chan %turn the appropriate light on. NOTE: This reflects the wiring state of our BLS controller. 
                    case {'625','FRFP','Crimson'}  %You will have to match channel numbers to LEDs for your specific setup. 
                        BLS.enableChannel(1);
                    case {'561','RFP','mCherry'}
                        BLS.enableChannel(2);
                    case {'470','GFP','gfp'}
                        BLS.enableChannel(3);
                    case {'405','BFP'}
                        BLS.enableChannel(4);
                    otherwise
                        display('Channel not recognized');
                end
                
                pause(1.05*tExp); %give a small buffer to ensure the LED is on for the entirety of the exposure. 
                
                writeline(obj.arduino,"1"); %send the voltage pulse to initiate the exposure
                pause(0.001); %short pause to ensure it arrives
                writeline(obj.arduino,"2"); %terminate the pulse
                
                pause(1.05*tExp); %Ensure the light stays on for the entire camera exposure.
                
                switch chan %Turn off the light
                    case {'625','FRFP','Crimson'}
                        BLS.disableChannel(1);
                    case {'561','RFP'}
                        BLS.disableChannel(2);
                    case {'470','GFP'}
                        BLS.disableChannel(3);
                    case {'405','BFP'}
                        BLS.disableChannel(4);
                    otherwise
                        display('Channel not recognized');
                end
                
                frame = getdata(obj.vid,1); %pull the image out of the buffer.
                
                if(~isempty(varargin)) %if we've supplied a file path, write the image to disk.
                    imwrite(frame,varargin{1});
                end
                
            else
                display('Camera not running. Start acquisition before triggering.');
            end
            
        end
        
        
        function obj = setROI(obj,xOffSet,yOffSet,width,height)
            %set the bounds of the acquisition frame. All units are in
            %pixels. Origin is the upper left hand corner of the image.
            
            %Note: I verified with Hamamatsu that setting it in this way
            %does activate the subarray function of the Fusion camera.

            obj.vid.ROIPosition = [xOffSet,yOffSet,width,height];
        end
        
        function obj = resetROI(obj)
            %Simple method to re-set the full frame camera ROI.
            obj.vid.ROIPosition = [0,0,2304,2304];
        end
        
        function obj = setDMDBoundary(obj,fullFrameIm,setFlag)
            %This function is intended to identify the boundaries of the
            %DMD in the camera view. In the current instantiation, the
            %camera FOV is much larger than the DMD chip; this function
            %will define an ROI so that we don't have large swaths of empty
            %frame.
            %
            %INPUTS: fullFrameIm: a full camera ROI image of a mirror or 
            % fluorescent film illuminated with all DMD pixels
            
            %if setFlag == 1, then the camera ROI is automatically updated.
            %Setting to 0 adds the ROI info to the camera object, but
            %doesn't change the setting itself.
            
            
            % To idenfity the boundaries of the DMD, segment it from the
            % fullFrameIm
            bin = imbinarize(fullFrameIm,0.5*graythresh(fullFrameIm));
            bin = bwlabel(bin,4);
            props = regionprops(bin,'Area','PixelIdxList','BoundingBox');
            [C,idx] = max([props(:).Area]); %in case we get more than one object, take the biggest.
            bin = 0*bin;
            bin(props(idx).PixelIdxList)=1;
            bin = imfill(bin,'holes');
            
            %now we want to find a rectangular FOV that fits entirely
            %within the DMD chip boundary.
            
            %Strategy is to start with a bounding box for the DMD area,
            %then shrink it until it is completely contained in the DMD
            %area.
            
            %bounding box format is [x y width height]
            done = 0;
            box = props(idx).BoundingBox;
            box = round(box);
            while(~done)
                
                vals = bin(box(2):box(2)+box(4),box(1):box(1)+box(3));
                
                if(sum(vals(:) == 0) ==0) %if the box lies completely within the DMD area, we're done.
                    
                    done = 1;
                else %if they're not all 1's, shave a layer off the box
                    box(1) = box(1) +1;
                    box(2) = box(2) +1;
                    box(3) = box(3) -2; %take off 2 to account for moving of the UL corner.
                    box(4) = box(4) -2;
                end
                
            end
            
            %we'll shave an extra layer off just to avoid boundary effects
            %in camera => DMD mapping.
            box(1) = box(1) +1;
            box(2) = box(2) +1;
            box(3) = box(3) -2;
            box(4) = box(4) -2;
            
            %write this result to the ROI of the camera
            if(setFlag)
                obj.setROI(box(1),box(2),box(3),box(4));
            end
            
            %save the calibration information to the camera object.
            obj.fullFrameIm = fullFrameIm;
            obj.DMDROI = box;
            
        end
        
        function obj = importCalibration(obj,calStruct)
            %In the GUI, we set up methods to calibrate the camera FOV to the
            %DMD. These can be exported to a .mat file. This function
            %takes that calibration data and adds it to the
            %camera object's properties. The calstruct argument can be passed
            %as a string (a path) or a loaded structure with fields camera
            %and DMD.
            
            if(isstring(calStruct)) %if the argument is a path
                
                calDat = load(calStruct);
                obj.DMDROI = calDat.camera.DMDROI;
                obj.fullFrameIm = calDat.camera.fullFrameIm;
                
            elseif(isstruct(calStruct)) %if the argument is a struct
                obj.DMDROI = calStruct.camera.DMDROI;
                obj.fullFrameIm = calStruct.camera.fullFrameIm;
                
            end
            
        end
        
        function obj = liveScale(obj,tExp)
            
            %The purpose of this method is to provide a simple way of
            %running an auto-scaled live view. This is primarily used in
            %the GUI
            
            %The argument is the exposure time, tExp, specified in SECONDS.
            
            if(~obj.vid.Running)
                start(obj.vid);
            end
            
            %Note: this live view only works if the trigger mode is set to
            %internal-- check the setting and change it if need be. If this
            %is done, modeFlag is set to 1 and triggers automatic resetting
            %at the end of the method call.
            
            modeFlag = 0;
            if(obj.vidSrc.TriggerSource == 'external')
                obj.vidSrc.TriggerSource = 'internal';
                modeFlag = 1;
            end
            
            obj.vidSrc.ExposureTime = tExp; %set the exposure time.
            
            h = axes;
            h2 = gcf;
            
            %This function only wokrs if we're in internal trigger mode.
            %This raises the issue of what happens if we want the camera in
            %external mode, but need to use the live view. The solution is
            %to use a closeout callback for the figure window; if modeFlag
            %=1 (i.e. if the trigger mode was changed) we'll put it back
            %upon closing the live window out.
            
            if(modeFlag)
                
                set(h2,'CloseRequestFcn',{@resetTriggerCloseout,obj});
                
            end
            
            ROIPosition = obj.vid.ROIPosition;
            ROISize = [ROIPosition(4),ROIPosition(3)];
            im = image(h,zeros(ROISize,'uint8')); %make a spot for the live view to appear
            
            %We already implemented this functionality in the GUI. The
            %function handle here points to that function. It can be found
            %in the GUI folder.
            setappdata(im,'UpdatePreviewWindowFcn',@liveViewScaleV2); %associate the live scale function
            setappdata(im,'Autoscale','On'); %this is a hold out from the GUI; need to set autoscale to ON.
            
            preview(obj.vid,im);
        end
        
    end
end

