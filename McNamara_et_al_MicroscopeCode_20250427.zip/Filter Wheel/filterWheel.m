classdef filterWheel < handle
    
    %======================================================================
    %PURPOSE: Build an object with methods to control
    %the status of our Edmund Optics 5-position filter wheel (product
    %number 84-889). 
    %
    %NOTE: this code requires access to the API for the filter wheel, which
    %is developed by Edmund Optics. These files are not provided in this
    %repo, but can be obtained by contacting Edmund. Required files are
    %called: OptecHID_FilterWheelAPI.dll and OptecHIDTools.dll
    %
    %CLASS METHODS:
    %obj = filterWheel(): Constructor for filter wheel object. Connects to
    %the filter wheel hardware. The software libraries required for
    %control must be MATLAB's search path. 
    %
    %delete(): Destructor method to disconnect from the filter wheel. 
    %
    %currentPosition = setPosition(obj, newposition): Move the filterwheel
    %to a state specified by newposition. newposition is a string that
    %specifies which emission filter is desired (e.g. GFP, DAPI, etc.) 
    %
    %homeWheel(obj): moves the wheel to 'home' position (position index 1).
    %It's a good idea to run this upon initializaton to ensure that the
    %wheel isn't stuck at an 'in between' state. 
    %======================================================================
    
   
    properties     
        
        currentPosition %an integer; specifies which filter wheel position the wheel is currently on. 
        optecAPI 
        optecTools
        filterWheelList
        filterWheelHandle
        filterWheelID %This is the actual filter wheel object that we call methods through; constructed using the API. 
        
    end
    
    methods

        function obj = filterWheel()
            %Constructor for the filterWheel class. This method establishes
            %connection to the filter wheel and loads the appropriate
            %software tools from the company (contained within the
            %FilterWheel folder). 
            
            %Load in the requisite software libraries from Optec
            %Note: they must already be on the search path for this to
            %work. 
            path1= which('OptecHID_FilterWheelAPI.dll'); 
            path2 = which('OptecHIDTools.dll'); 
            
            obj.optecAPI = NET.addAssembly(path1); 
            obj.optecTools = NET.addAssembly(path2); 
            
            obj.filterWheelHandle = OptecHID_FilterWheelAPI.FilterWheels; %create the filter wheel object through the API
            
            %get a list of filter wheels connected to the system; we index
            %into this to get our wheel connection. 
            obj.filterWheelList = obj.filterWheelHandle.FilterWheelList; 
            
            obj.filterWheelID = obj.filterWheelList.Item(0); %this points to our filter wheel.   

        end
        
        function delete(obj) %the destructor method for our filter wheel. 

            clear(obj);  

        end
        
        function currentPosition = setPosition(obj, newposition) 
            
            %Method takes a string specifying the wavelength or channel
            %(see switch statement below) and moves the filterwheel to the
            %appropriate position. 
            %
            %NOTE: the mapping between wheel position and filter ID is
            %specific to our microscope. You will have to alter the switch
            %statement below to fit your instrument and filters. 
            %
            %As an error check, it outputs that position if the move was
            %successful (currentPosition)
 
        try
            if isnumeric(newposition)==0    %check to see if input is in numeric form, if it isn't, change it to numeric
                
                newposition=lower(newposition); %convert to lowercase to simplify inputs
                
                %Below code section converts alphabetic inputs to numeric
                
                switch newposition
                    case {'405','dapi','bfp'}
                        newposition = 1;
                    case {'gfp','470'}
                        newposition = 2;
                    case {'mcherry','rfp','560'}
                        newposition = 3;
                    case {'crimson','frfp','625'}
                        newposition = 4;
                    otherwise
                        display('Channel input not recognized');
                end
            
            end 
            
            %Update values of the output variable, the overall
            %currentposition property, and the actual target
            %currentposition in the filterwheel, causing it to change.
            
            if(obj.filterWheelID.CurrentPosition ~= newposition) %only bother making a move if we're not already in position. 
                
                currentPosition = newposition;  %set function output currentPosition to specified newposition
                
                obj.filterWheelID.CurrentPosition = newposition;  %Change the filterwheel currentPosition attribute to newposition
                
                timing=0; %initialize the timing variable to keep track of the time
                
                while obj.filterWheelID.IsMoving == 1   %Check to see if the filter wheel is moving, if it is, count up and exit the program once ten minutes have passed
                    %Prevents the filter wheel from getting stuck in a loop
                    pause(0.1)
                    timing=timing+1;
                    if timing == 6000
                        fprintf('Filter wheel seems to have stalled, ten minutes has elapsed.')
                        quit;
                    end 
                end 
            end
        
            
        catch
            %Figure out what error is present and inform the user before
            %resetting the error state
            if obj.filterWheelID.ErrorState == 1
                fprintf('ErrorState(1): The 12VDC power supply has been disconnected')
            elseif obj.filterWheelID.ErrorState == 2
                fprintf('ErrorState(2): The device stalled during a Home of Move procedure')
            elseif obj.filterWheelID.ErrorState == 3
                fprintf('ErrorState(3): An invalid parameter was received during communication with the host(PC)')
            elseif obj.filterWheelID.ErrorState == 4
                fprintf('ErrorState(4): An attempt to Home the device was made while the device was already in motion')
            elseif obj.filterWheelID.ErrorState == 5
                fprintf('ErrorState(5): An attempt to change filter positions was made while the device was already in motion')
            elseif obj.filterWheelID.ErrorState == 6
                fprintf('ErrorState(6): An attempt to change filter positions was made before the device had been homed')
            elseif obj.filterWheelID.ErrorState == 7
                fprintf('ErrorState(7): Optec use only')
            elseif obj.filterWheelID.ErrorState == 8
                fprintf('ErrorState(8): Unknown critical error')
            end
            
            %Clear the current error state
            fprintf('Clearing Error State\n Please re-enter command')
            obj.filterWheelID.ClearErrorState()
        
        end %end try/catch
            obj.currentPosition = obj.filterWheelID.CurrentPosition; %Update currentPosition property to the actual position of the filter wheel.
            %Placing this here will ensure property will only be updated if
            %there is no error and the filterwheel has actually changed
            %positions
            
        end %end function
        
        
        function homeWheel(obj) %Should call the HomeDevice method of filterWheel ID property within the matlab object
           
            obj.filterWheelID.HomeDevice    %home the device
            fprintf('Wheel was homed \n')
            
        end %end function 
 
    
    end %end methods
end




