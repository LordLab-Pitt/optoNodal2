classdef Power_meter < handle
    
%==========================================================================
%POWER_METER
%
%PURPOSE: Creates an object to facilitate control of a ThorLabs PM100D
%pwoer meter connected to a windows machine via a USB port. 
%
%CLASS METHODS: 
%
%Power_meter(): A constructor method to connect to the instrument and set
%up the software object. No arguments are requried, but the method dose use
%a power meter serial number to connect. If you don't know this, you can
%get it through the windows control panel by checking objects connected to
%the USB ports. It should not change day to day. 
%
%delete(): A destructor method to gracefully unload the power meter. 
%
%setWavelength(obj,newLambda): A method to change the wavelength setting on
%the power meter. Obj is an implicit argument (doesn't need to be supplied).
%NewLambda is a uint16 that specifies the wavelength in nm. 
%
%setReplicates(obj,nCounts): specifies the number of replicates for 
% power measurements. nCounts is an integer and specifies how many replicate
%bmeasurements to take. It specifies in hundreds of replicates (i.e. 1 => 
%100 replicate measurements). 
%
%power = readPower(obj): Measure the current TOTAL power being picked up by
%the power meter probe. Power (output argument) is in Watts. Obj is
%implicit argument => no argument is needed. Wavelength and replicate
%settings are set with the methods above as object properties.
%==========================================================================

%Some of the code below is modified from: https://www.mathworks.com/matlabcentral/fileexchange/98884-controllers-for-thorlabs-pm100d
%This is built for a ThorLabs PM100D power meter connected via USB

    
    properties     
        
        usbString %the serial number and USB port information for the power meter
        lambda %the current wavelength setting for the meter. 
        thorObj % a container for the thorlabs object that we initiate. 
        nCounts %the replication level. 1 => 100 replicates per measurement, etc. 
        
    end
    
    methods
        function obj = Power_meter()
           
            try
                obj.usbString = 'USB0::0x1313::0x8078::P0032204::INSTR'; %This is the serial number for the Power meter instrument. You can find this by checking the USB port once it connects. 
                obj.lambda = 470; %default the power meter wavlength to 470 nm
                obj.nCounts = 1; %default to 100 replicate counts per measurement. 
                
                tag_str = ['thorpm_1']; %just a name for the thorlabs power meter
                
                %connect to the power meter.
                thorpm_obj = visa('ni',obj.usbString,'tag',tag_str,'timeout',3);
                
                %open the communictions
                fopen(thorpm_obj);
                
                %ask the meter to identify itself
                ret = query(thorpm_obj,'*IDN?');
                
                obj.thorObj = thorpm_obj; 
                
                %Set the default wavelength: 
                set_wavelength_str = num2str(obj.lambda);
                fprintf(obj.thorObj,['sense:correction:wavelength ', set_wavelength_str]);
                
                %Set the default number of measurement replicates 
                fprintf(obj.thorObj,['sense:average:count ',num2str(obj.nCounts)]);
                
             
                display('ThorLabs PM100D Power Meter Loaded'); 
                
                
            catch %Sometimes we won't use the power meter; in this event, have a graceful exit. 
                display('Power meter not detected'); 
            end
           
        end
        
        function delete(obj) %destructor method; clean up instrument connection before deleting.
            fclose(obj.thorObj);
            display(['Power Meter object unloaded']);      
        end
            
        function obj = setWavelength(obj,newLambda)
            %Sets the wavelength of the power meter. Takes a single
            %argument (newLambda), an int which specifies the wavelength
            %in nm. 
            
            %check to make sure the set value is within bounds. 
            range_min = str2num(query(obj.thorObj,'sense:correction:wavelength? minimum'));
            range_max = str2num(query(obj.thorObj,'sense:correction:wavelength? maximum'));
            
            if(newLambda >= range_min && newLambda <= range_max) 
                set_wavelength_str = num2str(newLambda);
                fprintf(obj.thorObj,['sense:correction:wavelength ', set_wavelength_str]); 
                
                %check to make sure that we've got the right wavelength
                setLambda = str2num(query(obj.thorObj,'sense:correction:wavelength?'));
                
                if(setLambda == newLambda) 
                    obj.lambda = newLambda; 
                    display(['Power meter wavelength set to ',num2str(newLambda),' nm']); 
                else 
                    display(['Wavelength change failed. Current setpoint is ',num2str(obj.lambda),' nm']); 
                end
                
            elseif(newLambda < range_min)
                
                newLambda = range_min; 
                set_wavelength_str = num2str(newLambda);
                fprintf(obj.thorObj,['sense:correction:wavelength ', set_wavelength_str]); 
                
                %check to make sure that we've got the right wavelength
                setLambda = str2num(query(obj.thorObj,'sense:correction:wavelength?'));
                
                if(setLambda == newLambda) 
                    obj.lambda = newLambda; 
                    display(['Requested wavelength is below the allowable range. Power meter wavelength set to ',num2str(newLambda),' nm']); 
                else 
                    display(['Wavelength change failed. Current setpoint is ',num2str(obj.lambda),' nm']); 
                end
                
            elseif(newLambda > range_max)
                
                newLambda = range_max;
                set_wavelength_str = num2str(newLambda);
                fprintf(obj.thorObj,['sense:correction:wavelength ', set_wavelength_str]);
                
                %check to make sure that we've got the right wavelength
                setLambda = str2num(query(obj.thorObj,'sense:correction:wavelength?'));
                
                if(setLambda == newLambda)
                    obj.lambda = newLambda;
                    display(['Requested wavelength is above the allowable range. Power meter wavelength set to ',num2str(newLambda),' nm']);
                else
                    display(['Wavelength change failed. Current setpoint is ',num2str(obj.lambda),' nm']);
                end
                
            end
        end
        
        function obj = setReplicates(obj,nCounts) 
            
           %Method specifies the number of replicates for power measurements.  
           %passed as an integer and specifies how many replicate
           %measurements to take. It specifies in hundreds of replicates
           %(i.e. 1 => 100 replicate measurements). 
           
           nCounts = nCounts*100; 
           %tell the device to average over the number of counts
           fprintf(obj.thorObj,['sense:average:count ',num2str(nCounts)]);
           
           if str2num(query(obj.thorObj,'sense:average:count?'))~=nCounts
               error('power meter is not setting counts correctly')
           else
                 obj.nCounts = nCounts/100; 
           end
           
        end
         
        
        function power = readPower(obj)
           %The purpose of this method is read the power from the PM100D
           %power meter at the currently set wavelength with the set 
           % number of replicate measurements. 
           
           %Note: the power here is output in Watts. 
           
           %perform a measurement
           ret = query(obj.thorObj,'read?');
           
           %now we have a 1-d character array.  Convert it to a number
           power = str2num(ret);

        end
 
      
    end
end

