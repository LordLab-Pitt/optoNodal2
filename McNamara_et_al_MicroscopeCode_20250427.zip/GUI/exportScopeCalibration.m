function out = exportScopeCalibration(cam,DMD,flatField,varargin) 

%==========================================================================
%PURPOSE: The calibration of the lumiere microscope will often occur within
%the context of the GUI. This function takes the calibration parameters and
%exports them to a struct that can be used to import the calibration
%results in e.g. an acquisition script. 
%
%INPUTS: cam: a camera object 
%
%        DMD: a DMD object 
%
%       flatField: the flatField property of the GUI. 
%
%       varargin: an LED power calibration structure (normally a property
%       of the GUI. 
%
%
%OUTPUTS: out: the output structure. Has fields 

%==========================================================================

%for the camera, we just need the info for the DMD chip size calibration 
out.camera.DMDROI = cam.DMDROI; 
out.camera.fullFrameIm = cam.fullFrameIm; 

%For the DMD, we want the transform that maps camera pixels to DMD pixels. 
out.DMD.tForm = DMD.tForm; 
out.DMD.calMask = DMD.calMask; 
out.DMD.calIm = DMD.calIm; 

%For the flat field, we want to store the images we took to calibrate the
%illumination profiles. Each channel has its own field in the structure. 

out.flatField = flatField; 

if(~isempty(varargin))
    calStruct = varargin{1};
    
    out.LED.power561 = calStruct.cal561;
    out.LED.power470 = calStruct.cal470;
    out.LED.power405 = calStruct.cal405;
    out.LED.LEDpCurent = calStruct.LEDPower; 
    out.LED.dutyCycle = calStruct.dutyCycles; 
    
end

out.date = date(); 




