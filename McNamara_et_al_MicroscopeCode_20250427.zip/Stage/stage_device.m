 classdef stage_device 

%==========================================================================
%STAGE_DEVICE
%
%PURPOSE: Creates an object to facilitate control of a Prior XYZ encoded
%stage. Our control of the XY (H101E1F XY stage) and Z (FB206E Z motor) is
%run through a Prior ProScan III controller. Our stage was connected via a
%COM port on a windows machine. 
%
%CLASS METHODS: 
%
%stage_device(varargin): Constructor method to connect to the stage controller and
%start the software object. By default (i.e. if variable argument is not
%specified) COM3 is used. Otherwise, the variable argument specified the
%COM port number (an int) to which the stage controller is connected. 
%
%delete(obj): Destructor method to unload the stage. Argument (obj) is
%implicit, so does not need to be specified. 
%
%disableJoystick(obj): Turn OFF control from the joystick. Our system has a
%joystick for manual control. Sometimes it's useful to disable the joystick
%during an acquisition so that we don't accidentally bump the stage's
%position. Obj (argument) is implicit, so does not need to be specified. 
%
%enableJoystick(obj): Turn ON control from the joystick. Our system has a
%joystick for manual control. Undoes the action of disableJoystick method
%Obj (argument) is implicit, so does not need to be specified. 
%
%moveXYZ(obj,dX,dY,dZ): Move the stage position by a defined increment in X
%(dX), Y (dY) and Z (dZ). Units of dX, dY and dZ are stage units (NOT
%microns).
%
%gotoXYZ(obj,X,Y,Z): Move the stage to a defined X,Y,Z position. Note: X, Y
%and Z are specified in stage units (NOT microns). In our experience, the
%'origin' appears reliable day to day because the stage is encoded. 
%
%[x,y,z] = queryPosition(obj): Get the current (X,Y,Z) position of the
%stage in stage units. Obj is implicit, so does not need to be supplied by
%the user in a method call. 
%==========================================================================
    
    properties 
        port   
    end
    
    methods 
        function obj = stage_device(varargin) %constructor method; takes optional numerical argument specifying which 
            if ~isempty(varargin)                   %COM port to call. 
                portNo = num2str(varargin{1}); 
                s = serialport(['COM',portNo],9600); %9600 is the default baud rate; specified in Prior documentation. 
                s.Terminator = "CR"; %carriage return is the required terminator for serial commands 
                obj.port = s; 
                
            elseif isempty(varargin) %default to COM3.  
                s = serialport(['COM3'],9600); 
                configureTerminator(s,"CR"); 
                obj.port = s; 
                
            end
        end
        
        function delete(obj) %destructor method; close out the port
            clear s; %I guess this is how it's handled now-- there's no specific closeout function for serial ports
        end
        
        function out = disableJoystick(obj) %toggle the joystick off
            writeline(obj.port,"H"); 
            output = readline(obj.port); %need to read the output to clear the buffer for subsequent commands. 
            out = obj; 
        end
        
        function out = enableJoystick(obj) %toggle the joystick on
            writeline(obj.port,"J"); 
            output = readline(obj.port); %need to read the output to clear the buffer for subsequent commands.
            out = obj; 
        end
        
        function out = moveXYZ(obj,dX,dY,dZ) %move the X,Y,Z axis of the stage. Units are stage units. 
            
            commandStr = ['GR,',num2str(dX),',',num2str(dY),',',num2str(dZ)]; 
            writeline(obj.port,commandStr); 
            output = readline(obj.port); %need to read the output to clear the buffer for subsequent commands.
            out = obj; 
            
        end
        
        function out = gotoXYZ(obj,X,Y,Z) %move the the position specified by absolute coordinate (X,Y,Z) 
           
           if(isempty(Z)) %if not specified, keep the current Z
              
              [x,y,z] = obj.queryPosition; 
               Z = z; 
           end
            
           commandStr = ['G,',num2str(X),',',num2str(Y),',',num2str(Z)];
           writeline(obj.port,commandStr); 
           output = readline(obj.port); %need to read the output to clear the buffer for subsequent commands
           out = obj; 
           
        end
        
        function [x,y,z] = queryPosition(obj) %get the current absolute position of the stage in X,Y,Z
        
            writeline(obj.port,'P');
            output = readline(obj.port);
            C = strsplit(output, ',');
            x = str2num(C(1));
            y = str2num(C(2));
            z = str2num(C(3));
            
            
        end
    end
end
